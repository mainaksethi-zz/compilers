#include <iostream>
#include "lex.h"
#include <stdio.h>
#include <ctype.h>
#include <string>
using namespace std;
char* yytext = ""; /* Lexeme (not '\0'
                      terminated)              */
int yyleng   = 0;  /* Lexeme length.           */
int yylineno = 0;  /* Input line number        */
//map <string,int> mymap;
int lex(void){

   static char input_buffer[1024];
   char        *current;

   current = yytext + yyleng; /* Skip current
                                 lexeme        */

   while(1){       /* Get the next one         */
      while(!*current ){
         /* Get new lines, skipping any leading
         * white space on the line,
         * until a nonblank line is found.
         */

         current = input_buffer;
         if(!gets(input_buffer)){
            *current = '\0' ;

            return EOI;
         }
         ++yylineno;
         while(isspace(*current))
            ++current;
      }
      for(; *current; ++current){
         /* Get the next token */
         yytext = current;
         yyleng = 1;
         switch( *current ){
           case ';':
            return SEMI;
           case '=' : 
            return ASSIGN;
           case '<' : 
            return LESS;
           case '>' : 
            return GREATER;
           case ':=' : 
            return COLON_EQUAL;
           case '+':
            return PLUS;
           case '-':
            return MINUS;
           case '*':
            return TIMES;
           case '/':
            return DIVIDE;
           case '(':
            return LP;
           case ')':
            return RP;
           case '\n':
           case '\t':
           case ' ' :
            break;
           default:
            if(!isalnum(*current))
               fprintf(stderr, "Agvonse la8emevn eisagwgn <%c>\n", *current);
            else{
                if(isdigit(*current))
                {
                   while(isalnum(*current))
                      ++current;
                   yyleng = current - yytext;
                   return NUM_OR_ID;
                }
                else
                {
                  string str;
                  while(isalnum(*current))
                  {
                      str=str+*current;
                      ++current;
                  }
                  yyleng = current - yytext;

                  if (str=="IF")
                  {
                    return IF;
                  }
                  else if (str == "THEN")
                  {
                    return THEN;
                  }
                  else if (str =="IF")
                    return IF;
                  else if (str =="THEN")
                     return THEN;
                  else if (str =="WHILE")
                    return WHILE; 
                  else if (str =="DO")
                    return DO; 
                  else if (str =="BEGIN")
                    return BEGIN;
                  else if (str =="END") 
                    return END;
                  else
                    return VAR;
                   
                }
            }
            break;
         }
      }
   }
}


static int Lookahead = -1; /* Lookahead token  */

int match(int token){
   /* Return true if "token" matches the
      current lookahead symbol.                */

   if(Lookahead == -1)
   {
      Lookahead = lex();
   }
   // cout<<Lookahead<<endl;
   return token == Lookahead;
}

void advance(void){
/* Advance the lookahead to the next
   input symbol.                               */

    Lookahead = lex();
}
