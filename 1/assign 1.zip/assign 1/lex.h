#define EOI		0	/* End of input			*/
#define SEMI	1	/* ; 				*/
#define PLUS 	2	/* + 				*/
#define MINUS	18
#define TIMES	3	/* * 				*/
#define DIVIDE	4	/* / 				*/
#define ASSIGN	5	/* = 				*/
#define	COLON_EQUAL	6	/* := 				*/
#define GREATER	7	/* > 				*/
#define LESS	8	/* < 				*/
#define LP		9	/* (				*/
#define RP		10	/* )				*/
#define NUM_OR_ID	11	/* Decimal Number or Identifier */
#define IF 12	/* if 				*/
#define THEN 13	/* then 				*/
#define WHILE 14	/* while 				*/
#define DO 15	/* do 				*/
#define	BEGIN 16	/* begin 				*/
#define END 17	/* end 				*/
#define VAR 19
extern char *yytext;		/* in lex.c			*/
extern int yyleng;
extern int yylineno;
extern void statements(void);
extern void factor     ( void );
extern void term       ( void );
extern void expression ( void );
extern void term5       ( void );
extern void term4       ( void );
extern void term3       ( void );
extern void term2       ( void );
extern void term1       ( void );
extern void statements_list(void);
extern void opt_statements(void);
extern int lex(void);
extern int match(int token);
extern void advance(void);