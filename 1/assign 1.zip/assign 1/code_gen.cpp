#include <iostream>
#include <cstdio>
#include "lex.h"
#include <map>
#include <string>
using namespace std;
void statements_list(void);
void opt_statements(void);
void factor     ( void );
void term5       ( void );
void term4       ( void );
void term3       ( void );
void term2       ( void );
void term1       ( void );
void expression0 ( void );
map <string,int> mymap;
string  glb_str;
int i=1;
void statements_list(void)
{
    while( !match(EOI) )
    {
       if(match(END))
         {
            advance();
            break;
         }
        statements();
        //if( match( SEMI ) )
          //  advance();
        //else
          //  fprintf( stderr, "%d: Inserting missing semicolon\n", yylineno );    
    }
}


void statements(void)
{
    /*  statements -> expression0 SEMI  |  expression0 SEMI statements |
    id := expression0; | if expression0 then statements | while expression0 do statements | begin opt_statements end 
     */
    int j;
    if(match(IF))
        {
            j=i;
            advance();
            expression0();
            if(match(THEN))
            {
                advance();
                statements();
                cout<<"FALSE_"<<j<<":"<<endl;
            }

            else
            {
               fprintf( stderr, "%d: missing then...wronfg syntax\n", yylineno );
            }

        }
 
        else if(match(WHILE))
        {
            j=i;
            static int k=1;
            cout<<"WHILE_"<<k<<":"<<endl;
            int k2 = k++;
            advance();
            expression0();
            if(match(DO))
            {
                advance();
                statements();
                cout<<"JMP WHILE_"<<k2<<endl;
                cout<<"FALSE_"<<j<<":"<<endl;
            }

            else
            {
               fprintf( stderr, "%d: missing do...wronfg syntax\n", yylineno );
            }

        }
         else if(match(BEGIN))
         {
             int j=i;
             cout<<"TRUE_"<<j<<":"<<endl;
             i++;
             advance();
             opt_statements();
             
         }
         // else if(match(END))
         // {
            
         //    advance();
         // }
        //  else
        // {
        //     fprintf( stderr, "%d: Insert missing end\n", yylineno );
        // }

         else
         {
            expression0();
            if( match( SEMI ) )
                advance();
            else
                fprintf( stderr, "%d: Inserting missing semicolon\n", yylineno );

            // while(!match(EOI))
            // {
            //     statements();
            // }
         }

    
}

void opt_statements(void){
    
    statements_list();

}



void expression0(void)
{
    /* expression0 -> term1 expression1
     * expression1 -> ASSIGN term expression1 |  epsilon
     */

    term1();
    string str=glb_str;
    while( match( ASSIGN ) )
    {
        advance();
        term1();
        cout<<"POP AX\n";
        cout<<"MOV "<<str<<", AX\n";
        //printf("    %s = %s\n", tempvar, tempvar2 );
    }

    return ;
}

void term1(void)
{

    term2();
    while( match( COLON_EQUAL ) )
    {
        advance();
        term2();
        cout<<"POP BX"<<endl;
        cout<<"POP AX"<<endl;
        cout<<"CMP AX, BX"<<endl;
        cout<<"JNE FALSE_"<<i<<endl;
        //printf("    %s := %s\n", tempvar, tempvar2 );
    }

    return ;
}

void term2(void)
{
    term3();
    while( match( GREATER ) || match( LESS ))
    {
        if(match( GREATER))
        {
            advance();
            term3();
            cout<<"POP BX"<<endl;
            cout<<"POP AX"<<endl;
            cout<<"CMP AX, BX"<<endl;
            cout<<"JLE FALSE_"<<i<<endl;
            //printf("    %s > %s\n", tempvar, tempvar2 );
        }
        else
        {
            advance();
            term3();
            cout<<"POP BX"<<endl;
            cout<<"POP AX"<<endl;
            cout<<"CMP AX, BX"<<endl;
            cout<<"JGE FALSE_"<<i<<endl;
            // i++;
            //printf("    %s < %s\n", tempvar, tempvar2 );
        }
    }
    
    return ;
}
void term3(void)
{

    term4();
    while( match( PLUS ) || match( MINUS ) )
    {
        //cout<<"aya"<<endl;
        if(match(PLUS)){
            advance();
            term4();
            cout<<"POP AX\n";
            cout<<"POP BX\n";
            printf("ADD AX,BX\n");
            cout<<"PUSH AX\n";
        }
        else{
            advance();
            term4();
            cout<<"POP BX\n";
            cout<<"POP AX\n";
            printf("SUB AX,BX\n");
            cout<<"PUSH AX\n";
            //printf("    %s -= %s\n", tempvar, tempvar2 );
           } 
    }

    return ;
}

void term4(void)
{
    factor();
    while( match( TIMES ) || match( DIVIDE ) )
    {
        if(match(TIMES))
        {
            advance();
            factor();
            cout<<"POP AX\n";
            cout<<"POP BX\n";
            // cout<<" MOV BL,AX\n";
            printf("MUL BX\n");
            cout<<"PUSH AX\n";
        }
        else
        {
            advance();
            factor();
            cout<<"POP BX\n";
            cout<<"POP AX\n";
            printf("DIV BX\n");
            cout<<"PUSH AX\n";   
            //printf("    %s /= %s\n", tempvar, tempvar2 );
        }
    }

    return ;
}

void factor(void)
{
    if( match(NUM_OR_ID))
    {
    /* Print the assignment instruction. The %0.*s conversion is a form of
     * %X.Ys, where X is the field width and Y is the maximum number of
     * characters that will be printed (even if the string is longer). I'm
     * using the %0.*s to print the string because it's not \0 terminated.
     * The field has a default width of 0, but it will grow the size needed
     * to print the string. The ".*" tells printf() to take the maximum-
     * number-of-characters count from the next argument (yyleng).
     */
        printf("MOV AX,%0.*s\n",yyleng, yytext );
        cout<<"PUSH    AX\n";
        advance();
    }
    else if(match(VAR))
    {
        string str;
        //int i=0;
        str=string(yytext,yytext+yyleng);
        if(mymap[str]==0)
        {
            cout<<str<<" DW 0"<<endl;
            mymap[str]=10;
            glb_str=str;
        }
        else
        {
            string check=string(yytext+yyleng,yytext+yyleng+1);
            //cout<<check<<endl;
            if(check == "=")
            {
                glb_str=str;
            }
            else
            {
                cout<<"MOV AX, "<<str<<endl;
                cout<<"PUSH AX"<<endl;
            }
        }
        advance();
    }    
    else if( match(LP) )
    {
        advance();
        expression0();
        if( match(RP) )
            advance();
        else
            fprintf(stderr, "%d: Mismatched parenthesis\n", yylineno );
    }
    else
    fprintf( stderr, "%d: Number or identifier expected\n", yylineno );

    return ;
}
