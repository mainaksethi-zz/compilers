#include <iostream>
#include "lex.h"
using namespace std;
int main ()
{
	cout<<"org 100h\n";
	statements_list();
	return 0;
}
